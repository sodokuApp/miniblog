# -*- coding: utf-8 -*-
from xmlrpc.client import ServerProxy
# if __name__ == '__main__':
#     s = ServerProxy("http://192.168.1.106:8080")
#     print(s.subtract(4,3))

# if __name__ == '__main__':
#     s = ServerProxy("http://127.0.0.1:8080")
#     print(s.get_string("hello"))


from xmlrpc.client import ServerProxy
def main():
    proxy = ServerProxy('http://127.0.0.1:7001')

    print("Here are the functions supported by this server:")

    print("next calculator addtogether: ")
    print(proxy.addtogether('x', 'y', 'z'))
    print(proxy.addtogether('x', 'y', 'z'))

    print(proxy.addtogether('x', 'y', 'z'))
    print(proxy.addtogether('x', 'y', 'z'))
    for method_name in proxy.system.listMethods():
        if method_name.startswith('system.'):
            continue

        signatures = proxy.system.methodSignature(method_name)
        if isinstance(signatures, list) and signatures:
            for signature in signatures:
                print('%s(%s)' % (method_name, signature))

        else:
            print('%s(...)' % (method_name,))

        method_help = proxy.system.methodHelp(method_name)
        # if method_help:
        #    print(' ', methodHelp)

    print(proxy.addtogether('x', 'y', 'z'))
    print("addtogether result ")


if __name__ == '__main__':
    main()