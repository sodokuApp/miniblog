# from xmlrpc.server import SimpleXMLRPCServer
#
# def add(x, y):
#     return x + y
#
# def subtract(x, y):
#     return x - y
#
# def multiply(x, y):
#     return x * y
#
# def divide(x, y):
#     return x / y
#
# server = SimpleXMLRPCServer(("0.0.0.0", 8080))
# print ("Listening on port 8080..." )
# server.register_multicall_functions()
# server.register_function(add, 'add')
# server.register_function(subtract, 'subtract')
# server.register_function(multiply, 'multiply')
# server.register_function(divide, 'divide')
# server.serve_forever()

# from xmlrpc.server import SimpleXMLRPCServer
# def respon_string(str):
#     return "get string :%s"%str
#
# if __name__ == '__main__':
#     s = SimpleXMLRPCServer(('0.0.0.0', 8080))
#     s.register_function(respon_string,"get_string")
#     s.serve_forever()

import operator, math
from xmlrpc.server import SimpleXMLRPCServer
from functools import reduce
from kazoo.client import KazooClient

zk = KazooClient(hosts='127.0.0.1:2181')
zk.start()

def main():
    server = SimpleXMLRPCServer(('127.0.0.1', 7002))
    server.register_introspection_functions()
    server.register_multicall_functions()
    server.register_function(addtogether)
    server.register_function(quadratic)
    server.register_function(remote_repr)

    print("Server ready")
    server.serve_forever()


def addtogether(*things):
    """Add together everything in the list things ."""
    return reduce(operator.add, things)


def quadratic(a, b, c):
    """Determine x values satisfying: a * x * x + b * x + c = 0"""
    b24ac = math.sqrt(b * b - 4.0 * a * c)
    return list(set([(-b - b24ac) / 2.0 * a, (-b + b24ac) / 2.0 * a]))


def remote_repr(arg):
    """return the repr() rendering of the supplied arg """
    return arg

if __name__ == '__main__':
    main()