from flask import Flask
from flask import render_template,request,redirect,url_for,session
from models import User,Question
from exts import db
from werkzeug.security import generate_password_hash, check_password_hash
from decorators import login_required
from datetime import datetime, timedelta

from app import login
from app import register
from app import question

import config
app = Flask(__name__)
app.config.from_object(config)
db.init_app(app)


app.register_blueprint(login.login)
app.register_blueprint(register.register)
app.register_blueprint(question.question)

if __name__ == '__main__':
    app.run()
