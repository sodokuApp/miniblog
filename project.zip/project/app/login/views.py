from app.login import login
from flask import render_template,request,session
from models import User,Question
from werkzeug.security import check_password_hash
import xmlrpc.client

s = xmlrpc.client.ServerProxy('http://192.168.1.107:4242')

# 显示首页
@login.route('/')
def index():
    context = {
        'questions': Question.query.order_by('-create_time').all()
    }
    if session.get('user_id'):
        user_id = session.get('user_id')
        user = User.query.filter(User.id == user_id).first()
        return render_template('index.html', user = user, **context)
    else:
        return render_template('index.html', **context)

# #登录
# @login.route('login/',methods=["GET","POST"])
# def login():
#     if request.method=="GET":
#         return render_template('login.html')
#     else:
#         email = request.form.get('email')
#         password = request.form.get('password')
#         user = User.query.filter(User.email == email).first()
#         context = {
#             'questions': Question.query.order_by('-create_time').all()
#         }
#         if user:
#             if check_password_hash(user.password, password):
#                 session['user_id']=user.id
#                 #如果想在31天内都不需要登录
#                 session.permanent=True
#                 return render_template('index.html',user = user, **context)
#             else:
#                 return u'The password is wrong.'
#         else:
#             return u'The email is invalid.'

#登录
@login.route('login/',methods=["GET","POST"])
def login():
    if request.method=="GET":
        return render_template('login.html')
    else:
        email = request.form.get('email')
        password = request.form.get('password')
        user = User.query.filter(User.email == email).first()
        context = {
            'questions': Question.query.order_by('-create_time').all()
        }
        if user:
            if check_password_hash(user.password, password):
                session['user_id']=user.id
                #如果想在31天内都不需要登录
                session.permanent=True
                re=s.isright(email,password)
                if re==1:
                    return render_template('index.html',user = user, **context)
            else:
                return u'The password is wrong.'
        else:
            return u'The email is invalid.'

