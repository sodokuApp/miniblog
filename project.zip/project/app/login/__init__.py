from flask import Blueprint

login = Blueprint('login',__name__,url_prefix='/',template_folder='templates')

from app.login import views