from flask import Blueprint

question= Blueprint('question',__name__,url_prefix='/question',template_folder='templates')

from app.question import views