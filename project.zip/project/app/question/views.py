from app.question import question
from flask import render_template,request,redirect,url_for,session
from models import User,Question
from exts import db
from decorators import login_required
#发布帖子
@question.route('/',methods=['GET','POST'])
@login_required
def question():
    if request.method == 'GET':
        user_id = session.get('user_id')
        user = User.query.filter(User.id == user_id).first()
        return render_template('question.html', user=user)
    else:
        title = request.form.get('title')
        content = request.form.get('content')
        question = Question(title=title, content=content)
        user_id=session.get('user_id')
        user=User.query.filter(User.id==user_id).first()
        question.author = user
        # question.author_id = user_id
        db.session.add(question)
        db.session.commit()
        return redirect(url_for('login.index'))
