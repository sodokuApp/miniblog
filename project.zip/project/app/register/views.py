from app.register import register
from flask import render_template,request,redirect,url_for
from models import User
from exts import db
from werkzeug.security import generate_password_hash

#注册
@register.route('/',methods=["GET","POST"])
def register():
    if request.method=="GET":
        return render_template('register.html')
    else:
        email = request.form.get('email')
        username = request.form.get('username')
        password1 = request.form.get('password1')
        password2 = request.form.get('password2')

        #check whether the email is already registered
        user=User.query.filter(User.email==email).first()
        if user:
            return u'This email is already registered. Please change another one'
        else:
        # check whether two passwords are the same
            if password1!=password2:
                return u'Passwords are not the same.'
            else:
                password=generate_password_hash(password1)
                user=User(email=email,username=username,password=password)
                db.session.add(user)
                db.session.commit()
                return redirect(url_for('login.login'))