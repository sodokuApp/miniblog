from flask import Blueprint

register= Blueprint('register',__name__,url_prefix='/register',template_folder='templates')

from app.register import views