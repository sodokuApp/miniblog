from xmlrpc.server import SimpleXMLRPCServer
s = SimpleXMLRPCServer(("192.168.1.107",4242))
def isright(email,password):
    return 1
s.register_function(isright)
s.serve_forever()